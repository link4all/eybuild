About
1. webs.exe - GoAhead 2.1.8 for Windows only

2. mini-httpd - for Linux only, start with folloing command:
   ./mini-httpd -c -p 8080 cgi-bin/**
                  
3. put your cgi into cgi-bin directory

4. open browser and try as following:
   http://ip:8080/cgi-bin/xxx.cgi

